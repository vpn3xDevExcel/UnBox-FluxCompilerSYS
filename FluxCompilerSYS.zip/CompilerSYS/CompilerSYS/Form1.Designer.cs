﻿namespace CompilerSYS
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            label1 = new Label();
            button2 = new Button();
            richTextBox1 = new RichTextBox();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button3 = new Button();
            button4 = new Button();
            richTextBox2 = new RichTextBox();
            checkBox1 = new CheckBox();
            label2 = new Label();
            button5 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(14, 14, 14);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(817, 49);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(14, 14, 14);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(75, 9);
            label1.Name = "label1";
            label1.Size = new Size(114, 25);
            label1.TabIndex = 1;
            label1.Text = "CompilerSYS";
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Desktop;
            button2.ForeColor = SystemColors.ButtonHighlight;
            button2.Location = new Point(758, 3);
            button2.Name = "button2";
            button2.Size = new Size(46, 40);
            button2.TabIndex = 4;
            button2.Text = "💉";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = Color.FromArgb(10, 10, 10);
            richTextBox1.ForeColor = Color.White;
            richTextBox1.Location = new Point(12, 82);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(555, 273);
            richTextBox1.TabIndex = 1;
            richTextBox1.Text = "---Welcome\n--UI by WRD Office\n--Made by FluxTeam\n--Inject  to use it--";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.RRC;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(69, 49);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Desktop;
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(12, 367);
            button1.Name = "button1";
            button1.Size = new Size(45, 41);
            button1.TabIndex = 3;
            button1.Text = "▶️";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.Desktop;
            button3.ForeColor = SystemColors.ButtonHighlight;
            button3.Location = new Point(611, 367);
            button3.Name = "button3";
            button3.Size = new Size(203, 41);
            button3.TabIndex = 5;
            button3.Text = "Compile";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.Desktop;
            button4.ForeColor = SystemColors.ButtonHighlight;
            button4.Location = new Point(75, 367);
            button4.Name = "button4";
            button4.Size = new Size(43, 41);
            button4.TabIndex = 6;
            button4.Text = "\U0001f6de";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // richTextBox2
            // 
            richTextBox2.BackColor = Color.FromArgb(10, 10, 10);
            richTextBox2.ForeColor = Color.White;
            richTextBox2.Location = new Point(611, 82);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(203, 273);
            richTextBox2.TabIndex = 7;
            richTextBox2.Text = "Compile here";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = SystemColors.ActiveCaptionText;
            checkBox1.ForeColor = SystemColors.ControlLightLight;
            checkBox1.Location = new Point(147, 374);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(114, 29);
            checkBox1.TabIndex = 8;
            checkBox1.Text = "CheckDLL";
            checkBox1.UseVisualStyleBackColor = false;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(267, 375);
            label2.Name = "label2";
            label2.Size = new Size(105, 25);
            label2.TabIndex = 9;
            label2.Text = "SYS Version";
            // 
            // button5
            // 
            button5.BackColor = SystemColors.Desktop;
            button5.ForeColor = SystemColors.ButtonHighlight;
            button5.Location = new Point(398, 367);
            button5.Name = "button5";
            button5.Size = new Size(169, 41);
            button5.TabIndex = 10;
            button5.Text = "📐";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(816, 420);
            Controls.Add(button5);
            Controls.Add(label2);
            Controls.Add(checkBox1);
            Controls.Add(button1);
            Controls.Add(richTextBox2);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(pictureBox1);
            Controls.Add(richTextBox1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "CompilerSYS";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private RichTextBox richTextBox1;
        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private RichTextBox richTextBox2;
        private CheckBox checkBox1;
        private Label label2;
        private Button button5;
    }
}
