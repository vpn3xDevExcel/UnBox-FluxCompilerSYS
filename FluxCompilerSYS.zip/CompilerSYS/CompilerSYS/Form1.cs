namespace CompilerSYS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Compiled");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("DLL Is Active");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Dark Mode: yes");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Injected");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Executed/Run the script");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Currently Using It");
        }
    }
}
